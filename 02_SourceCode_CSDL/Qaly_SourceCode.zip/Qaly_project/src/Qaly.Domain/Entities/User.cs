namespace Qaly.Domain.Entities;

public class User : BaseEntity
{
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = "Member";
    public bool IsActive { get; set; } = true;
    public string? AvatarUrl { get; set; }

    // Navigation properties
    public ICollection<Project> OwnedProjects { get; set; } = new List<Project>();
    public ICollection<ProjectMember> ProjectMemberships { get; set; } = new List<ProjectMember>();
    public ICollection<WorkGroup> OwnedWorkGroups { get; set; } = new List<WorkGroup>();
    public ICollection<WorkGroupMember> WorkGroupMemberships { get; set; } = new List<WorkGroupMember>();
    public ICollection<GroupMessage> GroupMessages { get; set; } = new List<GroupMessage>();
    public ICollection<Organization> OwnedOrganizations { get; set; } = new List<Organization>();
    public ICollection<OrganizationMember> OrganizationMemberships { get; set; } = new List<OrganizationMember>();
    public ICollection<AiJob> RequestedAiJobs { get; set; } = new List<AiJob>();
    public ICollection<AiGeneratedDraft> ConfirmedAiDrafts { get; set; } = new List<AiGeneratedDraft>();
    public ICollection<TaskItem> AssignedTasks { get; set; } = new List<TaskItem>();
    public ICollection<TaskItem> ReportedTasks { get; set; } = new List<TaskItem>();
    public ICollection<TaskComment> Comments { get; set; } = new List<TaskComment>();
    public ICollection<Notification> Notifications { get; set; } = new List<Notification>();
}

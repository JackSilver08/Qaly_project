using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Qaly.Domain.Entities;

namespace Qaly.Infrastructure.Data.Configurations;

public class TaskItemConfiguration : IEntityTypeConfiguration<TaskItem>
{
    public void Configure(EntityTypeBuilder<TaskItem> builder)
    {
        builder.HasKey(t => t.Id);
        builder.Property(t => t.Id).HasDefaultValueSql("NEWID()");

        // Number is allocated explicitly per project in QalyDbContext.SaveChanges,
        // so it must stay a plain (non store-generated) column.
        builder.Ignore(t => t.Key);

        builder.Property(t => t.Title).HasMaxLength(300).IsRequired();
        builder.Property(t => t.Status).HasMaxLength(20).IsRequired().HasDefaultValue("Todo");
        builder.Property(t => t.Priority).HasMaxLength(20).IsRequired().HasDefaultValue("Medium");
        builder.Property(t => t.IsPrivate).HasDefaultValue(false);
        builder.Property(t => t.IsPinned).HasDefaultValue(false);
        builder.Property(t => t.ContributesToProgress).HasDefaultValue(true);
        builder.Property(t => t.UpvoteCount).HasDefaultValue(0);
        builder.Property(t => t.DownvoteCount).HasDefaultValue(0);
        builder.Property(t => t.RowVersion).IsRowVersion();
        builder.Property(t => t.CreatedAt).HasDefaultValueSql("SYSDATETIMEOFFSET()");

        builder.HasOne(t => t.Project)
            .WithMany(p => p.Tasks)
            .HasForeignKey(t => t.ProjectId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne(t => t.Sprint)
            .WithMany(s => s.Tasks)
            .HasForeignKey(t => t.SprintId)
            .OnDelete(DeleteBehavior.ClientSetNull);

        builder.HasOne(t => t.Assignee)
            .WithMany(u => u.AssignedTasks)
            .HasForeignKey(t => t.AssigneeId)
            .OnDelete(DeleteBehavior.Restrict)
            .IsRequired(false);

        builder.HasOne(t => t.Reporter)
            .WithMany(u => u.ReportedTasks)
            .HasForeignKey(t => t.ReporterId)
            .OnDelete(DeleteBehavior.Restrict);

        // Indexes
        builder.HasIndex(t => t.ProjectId);

        // Task key uniqueness per project (backs "QALY-142" resolution).
        builder.HasIndex(t => new { t.ProjectId, t.Number }).IsUnique();
        builder.HasIndex(t => t.SprintId);
        builder.HasIndex(t => t.AssigneeId);
        builder.HasIndex(t => t.Status);
        builder.HasIndex(t => t.DueDate);
        builder.HasIndex(t => t.StartDate);
        builder.HasIndex(t => t.IsPinned);
        builder.HasIndex(t => new { t.ProjectId, t.AssigneeId, t.Status });
        builder.HasIndex(t => new { t.ProjectId, t.SprintId, t.Status });
        builder.HasIndex(t => new { t.ProjectId, t.DueDate });

        builder.HasOne(t => t.ImportSession)
            .WithMany(s => s.ImportedTasks)
            .HasForeignKey(t => t.ImportSessionId)
            .OnDelete(DeleteBehavior.NoAction)
            .IsRequired(false);

        builder.HasIndex(t => t.ImportSessionId);

        // Optimization: Kanban board query (CH 2.2)
        builder.HasIndex(t => new { t.ProjectId, t.Status })
            .IncludeProperties(t => new { t.Title, t.Priority, t.AssigneeId, t.DueDate, t.IsPinned, t.ContributesToProgress });
        builder.HasIndex(t => new { t.ProjectId, t.Status, t.SortOrder });
    }
}
